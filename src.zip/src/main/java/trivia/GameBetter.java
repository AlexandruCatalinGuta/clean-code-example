package trivia;

import java.util.ArrayList;
import java.util.LinkedList;

// REFACTOR ME
public class GameBetter implements IGame {
  private ArrayList<String> players = new ArrayList<>();
  private int[] places = new int[6];
  private int[] purses = new int[6];
  private boolean[] inPenaltyBox = new boolean[6];

  private LinkedList<String> popQuestions = new LinkedList<>();
  private LinkedList<String> scienceQuestions = new LinkedList<>();
  private LinkedList<String> sportsQuestions = new LinkedList<>();
  private LinkedList<String> rockQuestions = new LinkedList<>();

  private int currentPlayer = 0;
  private boolean isGettingOutOfPenaltyBox;

  public GameBetter() {
    for (int i = 0; i < 50; i++) {
      popQuestions.addLast(createQuestion(i, QuestionCategory.POP));
      scienceQuestions.addLast(createQuestion(i, QuestionCategory.SCIENCE));
      sportsQuestions.addLast(createQuestion(i, QuestionCategory.SPORTS));
      rockQuestions.addLast(createQuestion(i, QuestionCategory.ROCK));
    }
  }

  private String createQuestion(int index, QuestionCategory questionCategory) {
    return questionCategory + " Question " + index;
  }

  public boolean add(String playerName) {
    players.add(playerName);
    int noPlayers = howManyPlayers();
    places[noPlayers] = 0;
    purses[noPlayers] = 0;
    inPenaltyBox[noPlayers] = false;

    System.out.println(playerName + " was added");
    System.out.println("They are player number " + players.size());
    return true;
  }

  private int howManyPlayers() {
    return players.size();
  }

  public void roll(int roll) {
    System.out.println(players.get(currentPlayer) + " is the current player");
    System.out.println("They have rolled a " + roll);

    if (inPenaltyBox[currentPlayer]) {
      penaltyBoxBehavior(roll);

    } else {
      advancePlayer(roll);
    }

  }

  private void advancePlayer(int roll) {
    places[currentPlayer] = (places[currentPlayer] + roll) % 12;

    System.out.println(players.get(currentPlayer)
            + "'s new location is "
            + places[currentPlayer]);
    System.out.println("The category is " + currentCategory());
    askQuestion();
  }

  private void penaltyBoxBehavior(int roll) {
    if (roll % 2 != 0) {
      isGettingOutOfPenaltyBox = true;

      System.out.println(players.get(currentPlayer) + " is getting out of the penalty box");
      advancePlayer(roll);
    } else {
      System.out.println(players.get(currentPlayer) + " is not getting out of the penalty box");
      isGettingOutOfPenaltyBox = false;
    }
  }

  private void askQuestion() {
    switch (currentCategory()) {
      case POP -> System.out.println(popQuestions.removeFirst());
      case SCIENCE -> System.out.println(scienceQuestions.removeFirst());
      case SPORTS -> System.out.println(sportsQuestions.removeFirst());
      case ROCK -> System.out.println(rockQuestions.removeFirst());
    }
  }


  private QuestionCategory currentCategory() {
    return switch (places[currentPlayer]) {
      case 0, 4, 8 -> QuestionCategory.POP;
      case 1, 5, 9 -> QuestionCategory.SCIENCE;
      case 2, 6, 10 -> QuestionCategory.SPORTS;
      default -> QuestionCategory.ROCK;
    };
  }

  public boolean wasCorrectlyAnswered() {
    if (inPenaltyBox[currentPlayer]) {
      if (isGettingOutOfPenaltyBox) {
        return correctAnswer();
      } else {
        nextPlayer();
        return true;
      }

    } else {
      return correctAnswer();
    }
  }

  private boolean correctAnswer() {
    System.out.println("Answer was correct!!!!");
    purses[currentPlayer]++;
    System.out.println(players.get(currentPlayer)
            + " now has "
            + purses[currentPlayer]
            + " Gold Coins.");

    boolean winner = didPlayerWin();
    nextPlayer();

    return winner;
  }

  private void nextPlayer() {
    currentPlayer++;
    if (currentPlayer == players.size()) {
      currentPlayer = 0;
    }
  }

  public boolean wrongAnswer() {
    System.out.println("Question was incorrectly answered");
    System.out.println(players.get(currentPlayer) + " was sent to the penalty box");
    inPenaltyBox[currentPlayer] = true;

    nextPlayer();
    return true;
  }


  private boolean didPlayerWin() {
    return purses[currentPlayer] != 6;
  }
}
