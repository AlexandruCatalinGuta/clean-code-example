package trivia;

public enum QuestionCategory {
  POP("Pop"),
  SCIENCE("Science"),
  ROCK("Rock"),
  SPORTS("Sports");
  final String category;

  QuestionCategory(String category) {
    this.category = category;
  }
}
